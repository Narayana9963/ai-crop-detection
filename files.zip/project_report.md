# AI-Powered Crop Disease Detection and Smart Farming Assistant

## 1. Title Page
**Project title:** AI-Powered Crop Disease Detection and Smart Farming Assistant
**Theme:** Artificial Intelligence for Social Good
**Submitted by:** [Student name] ([Roll number])
**Programme:** B.Tech Computer Science and Engineering (Artificial Intelligence and Machine Learning)
**Guide:** [Guide name]  |  **Institution:** [College name]  |  **Academic year:** [Year]

> How to use this report: sections marked **[TO FILL]** must be completed with *your own measured results*
> after running the project. Nothing in this template is an experimental result.

## 2. Abstract
Crop diseases reduce yield and farmer income, and many farmers cannot reach an expert quickly. This project
builds a web application in which a farmer uploads a photo of a tomato, potato or bell-pepper leaf. A
MobileNetV2 convolutional neural network, fine-tuned by transfer learning on the PlantVillage dataset,
predicts the disease class and a confidence score. A structured knowledge base then shows symptoms, causes,
preventive measures and next steps in English and Telugu, without giving pesticide doses. Predictions are
stored in SQLite and summarised on a dashboard. A retrieval-based assistant answers predefined questions.
The system warns the user when confidence is low or the image does not look like a leaf, and states clearly
that results are preliminary. **[TO FILL: one sentence with your measured test accuracy and macro-F1.]**

## 3. Introduction
Agriculture supports a large share of livelihoods in India. Diseases such as late blight can destroy a crop
within days, so early identification matters. Machine learning can recognise visual disease patterns on
leaves from a smartphone photo. This project applies that idea in a simple, explainable, farmer-friendly tool.

## 4. Problem Statement
Small farmers often lack quick access to plant-pathology experts. Misidentifying a disease leads to late or
wrong action. The problem is to build a low-cost tool that gives early, understandable, *cautious* guidance from
a leaf image, in a local language, while making its uncertainty and limits obvious.

## 5. Motivation and Societal Relevance
* Early detection can reduce crop loss and protect income.
* A Telugu interface lowers the language barrier for farmers in Telugu-speaking regions.
* Preventive guidance (sanitation, rotation, watering practice) reduces unnecessary chemical use.
* The project also practises *responsible AI*: honest confidence, uncertainty warnings and expert referral.

## 6. Objectives
1. Classify leaf images of tomato, potato and bell pepper into healthy and disease classes.
2. Show the top predictions with confidence and warn about low confidence/unsupported images.
3. Provide verified disease information and prevention advice in English and Telugu.
4. Store prediction history and show analytics and model evaluation.
5. Provide a retrieval-based educational assistant.
6. Evaluate honestly with a held-out test set and discuss limitations.

## 7. Existing System
Farmers currently rely on personal experience, neighbours, agricultural extension officers, Krishi Vigyan
Kendras (KVKs) or shop dealers. These sources are valuable but may be slow, far away or inconsistent. Several
research prototypes and mobile apps for plant disease recognition exist; many are English-only, need internet
or give no uncertainty information. *(Describe specific apps you actually reviewed here.)*

## 8. Proposed System
A Streamlit web application with six pages (Home, Disease Detection, Farming Assistant, Prediction History,
Analytics, About). Inference uses a separately trained model file; a knowledge base supplies verified text;
SQLite stores history. The application refuses to run detection if the model is missing rather than faking output.

## 9. Literature Review
*(Read the papers yourself before submission and add your own comparison; cite only sources you have read.)*
* **Hughes & Salathe (2015)** describe the open PlantVillage repository of labelled plant-health images, which
  made deep-learning research on plant disease possible.
* **Mohanty, Hughes & Salathe (2016)** trained deep CNNs on PlantVillage and reported very high accuracy on
  held-out lab images, while noting a large drop when testing on images from different conditions. This is the
  motivation for our warning that real farm photos may perform worse.
* **Sandler et al. (2018)** proposed MobileNetV2, an efficient network suitable for CPUs and phones, which we use.
* Transfer learning from ImageNet is a standard way to train accurate image classifiers with limited data and compute.

## 10. System Requirements
**Hardware:** any laptop with 8 GB RAM (CPU training works but is slow; a GPU or Google Colab is optional).
**Software:** Windows 10/11, Python 3.10/3.11, VS Code, TensorFlow 2.16, Streamlit, scikit-learn, Pillow,
Matplotlib, Plotly, SQLite (built into Python).

## 11. System Architecture
```mermaid
flowchart TD
    A[User uploads leaf image] --> B[Validation & preprocessing]
    B --> C[Trained MobileNetV2 classifier]
    C --> D[Predicted class + confidence]
    D --> E{Confidence and image checks}
    E --> F[Knowledge base: disease information]
    F --> G[Farming recommendations]
    G --> H[Results page]
    H --> I[(SQLite history)]
    I --> J[Dashboard & analytics]
    K[train_model.py - offline] -.creates.-> C
```
Training (`train_model.py`) is separate from inference (`predict.py`, `app.py`). They share only the saved
model file and `class_names.json`.

## 12. Data Flow Diagram (Level 1)
```mermaid
flowchart LR
    U[Farmer] -->|leaf image, language| P1(1. Validate & preprocess)
    P1 -->|clean image array| P2(2. Classify)
    M[(Model file)] --> P2
    P2 -->|probabilities| P3(3. Uncertainty checks)
    P3 -->|class, confidence, status| P4(4. Retrieve information)
    KB[(Knowledge base)] --> P4
    P4 -->|advice| U
    P3 -->|record| D[(SQLite history)]
    D -->|statistics| P5(5. Dashboard)
    P5 --> U
    U -->|question| P6(6. Q&A retrieval)
    KB2[(Q&A set)] --> P6
    P6 -->|answer| U
```

## 13. Use Case Diagram
```mermaid
flowchart LR
    F((Farmer / Student))
    F --- UC1[Upload leaf image]
    F --- UC2[View prediction & confidence]
    F --- UC3[Read disease information]
    F --- UC4[Ask farming question]
    F --- UC5[View / search / clear history]
    F --- UC6[View analytics]
    F --- UC7[Switch language]
    D((Developer)) --- UC8[Train model]
    D --- UC9[Evaluate model]
```

## 14. Activity Diagram
```mermaid
flowchart TD
    S([Start]) --> U[Upload image]
    U --> V{Valid JPG/PNG, size OK, readable?}
    V -- No --> E1[Show error] --> U
    V -- Yes --> M{Model file present?}
    M -- No --> E2[Show model-missing message] --> Z([End])
    M -- Yes --> L{Looks like a leaf?}
    L -- No --> E3[Show unsupported-image message] --> Z
    L -- Yes --> P[Run CNN]
    P --> C{Confidence >= 70%?}
    C -- No --> W[Warn: uncertain, consult expert]
    C -- Yes --> OK[Show result]
    W --> I[Show info for most likely class]
    OK --> I
    I --> DB[Save to SQLite]
    DB --> Z
```

## 15. Methodology
1. Collect the PlantVillage images for pepper, potato and tomato.
2. Remove duplicate files; split file paths 70/15/15 (stratified) before augmentation.
3. Build the model: augmentation -> MobileNetV2 normalisation -> frozen MobileNetV2 -> pooling -> dropout -> softmax.
4. Phase 1: train only the new head (learning rate 1e-3). Phase 2: unfreeze the last 30 base layers and fine-tune (1e-5).
5. Use class weights, early stopping, learning-rate reduction and checkpoints.
6. Evaluate once on the untouched test set; report accuracy, precision, recall, F1 and a confusion matrix.
7. Integrate the model into the app with confidence and image checks, knowledge base, history and dashboard.

## 16. AI and ML Concepts Used
| Concept | Role in this project |
|---|---|
| Machine learning | The model learns disease patterns from labelled images instead of hand-written rules. |
| Deep learning (CNN) | Convolution layers learn edges -> textures -> spot/lesion patterns automatically. |
| Transfer learning | MobileNetV2 pretrained on ImageNet is reused and fine-tuned, needing less data and time. |
| Image processing | Validation, RGB conversion, resizing to 224x224, normalisation to [-1, 1], leaf-colour check. |
| Classification | Output layer assigns one of 15 classes. |
| Probability & confidence | Softmax gives probabilities; <70 % triggers an uncertainty warning; confidence is not correctness. |
| Knowledge-based system | Disease facts and advice come from a curated structure, not from generated text. |
| NLP | TF-IDF character n-grams + cosine similarity retrieve the best stored answer (English and Telugu). |
| Data visualisation | Plotly charts of healthy vs diseased and disease distribution; training curves and confusion matrix. |
| Model evaluation | Accuracy, per-class precision/recall/F1, confusion matrix on a held-out test set. |

## 17. Dataset Description
PlantVillage: labelled leaf images photographed on plain backgrounds. We use the 15 classes of pepper (2),
potato (3) and tomato (10). See `data/README.md` for source, licence and structure. **[TO FILL: total images,
duplicates removed, train/val/test sizes and per-class counts printed by `train_model.py`.]**
*Class imbalance:* some classes have many more images than others. A model can reach high overall accuracy
while performing poorly on small classes; we use class weights and report per-class recall and F1.
*Limitations of the data:* lab-style images; multiple photos per leaf may make test accuracy optimistic.

## 18. Model Training Procedure
Command: `python train_model.py --data-dir data\PlantVillage --epochs 8 --fine-tune-epochs 4`.
**[TO FILL: hardware used, training time, epochs actually run, final training/validation accuracy. Insert
`reports/figures/accuracy.png` and `loss.png`.]**

## 19. Implementation Details
| File | Purpose |
|---|---|
| `app.py` | Streamlit pages, language switching, result display, charts |
| `train_model.py` | Dataset split, training, checkpoints, plots, model saving |
| `predict.py` | Loads model, produces top-k, confidence status; raises an error if the model is missing |
| `utils/preprocessing.py` | Upload validation (extension, real format, size, corruption), preprocessing |
| `utils/dataset.py` | Discovery, de-duplication, leak-free split, tf.data pipeline |
| `utils/knowledge_base.py`, `recommendations.py` | Structured bilingual disease information |
| `utils/assistant.py` | Retrieval-based Q&A |
| `utils/database.py` | SQLite history (parameterised queries, error wrapping) |
| `evaluation/evaluate_model.py` | Test-set metrics and confusion matrix |

## 20. Screenshots
*(Capture real screenshots after running the app; do not use mock images.)*
| Figure | Page | Status |
|---|---|---|
| Fig. 1 | Home page | [Screenshot to be added] |
| Fig. 2 | Detection - healthy leaf | [Screenshot to be added] |
| Fig. 3 | Detection - diseased leaf with info | [Screenshot to be added] |
| Fig. 4 | Low-confidence / unsupported warning | [Screenshot to be added] |
| Fig. 5 | Telugu interface | [Screenshot to be added] |
| Fig. 6 | Farming Assistant | [Screenshot to be added] |
| Fig. 7 | Prediction History | [Screenshot to be added] |
| Fig. 8 | Analytics with evaluation metrics | [Screenshot to be added] |

## 21. Testing and Test Cases
Twelve test cases (TC-01 to TC-12) are listed in `docs/test_cases.md` with an *actual result* column.
The author ran 29 automated unit tests (`tests/test_core.py`) covering validation, preprocessing, knowledge
base, translations, database, assistant and dataset splitting. **[TO FILL: results of your manual UI/model
test runs, with date and Pass/Fail.]**

## 22. Evaluation Metrics and Actual Results
**No results are reported here because none have been measured by the author.** After running
`evaluation/evaluate_model.py`, copy the values from `evaluation/metrics.json`:
| Metric | Measured value |
|---|---|
| Test images | [TO FILL] |
| Accuracy | [TO FILL] |
| Macro precision / recall / F1 | [TO FILL] |
| Weighted F1 | [TO FILL] |
Insert `reports/figures/confusion_matrix.png` and the per-class table. *Expected* (not measured) behaviour:
published work reports high accuracy on PlantVillage lab images, but accuracy on real farm photos is usually
lower. Discuss which classes your model confuses (typically visually similar blights/spots) and relate it to
class counts.

## 23. Limitations
* Only 3 crops / 15 classes; no "unknown" class - the leaf-colour check is a simple heuristic, not a detector.
* Lab-style training images; possible optimistic test scores because of multiple photos per leaf.
* Confidence is not calibrated and not a guarantee.
* Telugu translations need expert review; no region-specific or pesticide advice by design.
* One leaf per image; no severity estimation.

## 24. Future Enhancements
Train with real field images; add more crops; add an "unknown/not a leaf" class and out-of-distribution
detection; Grad-CAM explanations; calibration of confidence; offline mobile app with Telugu voice;
expert-verified, location-aware advice; feedback loop where experts correct predictions.

## 25. Conclusion
The project demonstrates an end-to-end, responsibly designed AI application: data preparation, transfer
learning, evaluation, a knowledge-based advice layer, a bilingual interface and persistent history. Its value
as a social-good tool depends on honest evaluation and on being used as decision support alongside
agricultural experts. **[TO FILL: conclude with your measured results.]**

## 26. References
*(Verify each reference yourself and add the ones you actually read.)*
1. D. P. Hughes and M. Salathe, "An open access repository of images on plant health to enable the development of mobile disease diagnostics," arXiv:1511.08060, 2015.
2. S. P. Mohanty, D. P. Hughes and M. Salathe, "Using deep learning for image-based plant disease detection," *Frontiers in Plant Science*, vol. 7, article 1419, 2016.
3. M. Sandler, A. Howard, M. Zhu, A. Zhmoginov and L.-C. Chen, "MobileNetV2: Inverted residuals and linear bottlenecks," *CVPR*, 2018.
4. PlantVillage dataset repository: https://github.com/spMohanty/PlantVillage-Dataset
5. TensorFlow/Keras documentation: https://www.tensorflow.org/ ; Streamlit documentation: https://docs.streamlit.io/ ; scikit-learn documentation: https://scikit-learn.org/
