# AI-Powered Crop Disease Detection and Smart Farming Assistant

B.Tech CSE (AI & ML) mini project - theme: *Artificial Intelligence for Social Good*.
Upload a photo of a tomato, potato or bell-pepper leaf; a MobileNetV2 transfer-learning model predicts
the disease with a confidence score, and a verified knowledge base (English + Telugu) shows
symptoms, causes, prevention and next steps. Predictions are stored in SQLite.

> **Honest status.** This repository contains complete source code, but **no trained model and no
> measured results**. You must download the dataset and run `train_model.py` yourself.
> Until then the app shows a clear "model not found" message - it never fakes predictions.
> Predictions are preliminary and are **not** a professional diagnosis.

## What has and has not been verified
| Part | Status |
|---|---|
| Validation, preprocessing, knowledge base, translations, DB, assistant, dataset split (`tests\test_core.py`, 29 tests) | Executed and passing in the authoring environment (Python 3.12, no TensorFlow) |
| `train_model.py`, `evaluate_model.py`, model loading in `predict.py`, Streamlit UI | **Written but not executed** by the author (no TensorFlow/Streamlit/dataset available). Expect to fix small environment issues on first run. |
| Model accuracy / metrics | **None yet.** Run training + evaluation to get real numbers. |

## Project structure
```
crop-disease-ai/
├── app.py                  Streamlit UI (6 pages, English/Telugu)
├── train_model.py          Training (transfer learning, checkpoints, curves, test measurement)
├── predict.py              Inference: loads model, confidence/uncertainty logic (no TF at import)
├── requirements.txt
├── .streamlit/config.toml  5 MB upload limit, theme
├── models/                 model_placeholder.txt; training creates the .keras model + class_names.json here
├── data/README.md          Dataset download + split explanation
├── database/               prediction_history.db is created automatically at first run
├── utils/
│   ├── config.py           paths, thresholds
│   ├── preprocessing.py    upload validation, resize/normalise, leaf-colour check
│   ├── dataset.py          file discovery, de-duplication, leak-free stratified split, tf.data
│   ├── knowledge_base.py   structured disease data (EN + TE)
│   ├── recommendations.py  class name -> knowledge-base entry
│   ├── assistant.py        TF-IDF retrieval Q&A (EN + TE)
│   ├── translations.py     UI strings (EN + TE)
│   └── database.py         SQLite history
├── evaluation/evaluate_model.py   accuracy, precision, recall, F1, confusion matrix on the test split
├── tests/test_core.py      automated tests (unittest)
├── docs/                   test_cases.md, viva_questions.md
└── reports/project_report.md      academic report (+ figures/ folder for generated charts)
```

## 1. Install (Windows PowerShell)
Use 64-bit **Python 3.10 or 3.11**.
```powershell
cd crop-disease-ai
python -m venv .venv
.\.venv\Scripts\Activate.ps1          # if blocked: Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
python -m pip install --upgrade pip
pip install -r requirements.txt
```
No GPU is needed: TensorFlow uses the CPU automatically (slower). On CPU, start with the quick test
below, then train on the full dataset (expect from tens of minutes to a few hours depending on the PC).
Google Colab (free GPU) also works: upload the project, `pip install -r requirements.txt`, mount Drive
for the dataset, and run the same commands with `!`.

## 2. Get the dataset
Follow `data\README.md`, ending with `data\PlantVillage\<class folders>`.

## 3. Train
```powershell
# quick CPU smoke test (proves the pipeline runs; the model is NOT meaningful)
python train_model.py --data-dir data\PlantVillage --limit-per-class 60 --epochs 2 --fine-tune-epochs 1
# real training
python train_model.py --data-dir data\PlantVillage --epochs 8 --fine-tune-epochs 4
```
The first run downloads ImageNet weights for MobileNetV2 (internet needed once).
Outputs: `models\crop_disease_model.keras`, `models\class_names.json`, `models\splits.json`,
`reports\figures\accuracy.png`, `reports\figures\loss.png`.

## 4. Evaluate on the held-out test set
```powershell
python evaluation\evaluate_model.py
```
Creates `evaluation\metrics.json` and `reports\figures\confusion_matrix.png`, and prints the
per-class report. Copy these **measured** numbers into `reports\project_report.md` section 22.

## 5. Run the app
```powershell
streamlit run app.py
```
Open <http://localhost:8501>. If you trained while the app was open, press **Reload model** on the
Disease Detection page. Quick command-line check: `python predict.py path\to\leaf.jpg`.

## 6. Run the automated tests
```powershell
python -m unittest discover -s tests -v
```

## Sample demonstration workflow (for viva / demo)
1. Home page: explain the problem, point to the disclaimer, switch language to Telugu and back.
2. Detection: upload a test-set image of a diseased leaf -> prediction, top-3, confidence, info.
3. Upload a healthy leaf -> "healthy" result and monitoring advice.
4. Upload a non-leaf photo (e.g. a face) -> "unsupported" message. Upload a `.txt` -> rejected.
5. Upload a blurry/odd photo -> low-confidence warning and expert-consultation advice.
6. Farming Assistant: click a suggested question; ask "which pesticide dose?" -> safe refusal.
7. History: search/filter, open an entry, clear history. Analytics: charts + measured metrics.
8. Temporarily rename `models\crop_disease_model.keras` -> show the "model not found" error.

## Responsible-AI notes
* No personal data is collected; history stays in a local SQLite file (thumbnails only).
* Uploads are validated by real content (not just file name), size-limited, and never executed.
* Confidence is a probability estimate, not a guarantee; below 70 % the app warns the user.
* PlantVillage images are lab-style (single leaf, plain background). Accuracy on real farm photos
  can be much lower - say so in your demo.
* No pesticide names or doses are provided. Telugu text should be reviewed by a native speaker.
